import { RenderItem } from "./json";
export declare const BOKEH_ROOT = "bk-root";
export declare function _resolve_element(item: RenderItem): HTMLElement;
export declare function _resolve_root_elements(item: RenderItem): HTMLElement[];
