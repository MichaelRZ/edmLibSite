export declare function isEqual(a: any, b: any): boolean;
