:orphan:

.. index::
   single: examples; {{ filename }}

{{ filename }}
{{ '-' * filename|length }}

.. bokeh-plot:: {{ source_path }}
    :source-position: below
