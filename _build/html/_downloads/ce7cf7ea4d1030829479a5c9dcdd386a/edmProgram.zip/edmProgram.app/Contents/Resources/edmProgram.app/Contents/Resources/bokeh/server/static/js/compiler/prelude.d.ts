export declare function prelude(): string;
export declare function plugin_prelude(options?: {
    version?: string;
}): string;
export declare function default_prelude(options?: {
    global?: string;
}): string;
