export declare function throttle(func: () => void, wait: number): () => Promise<void>;
