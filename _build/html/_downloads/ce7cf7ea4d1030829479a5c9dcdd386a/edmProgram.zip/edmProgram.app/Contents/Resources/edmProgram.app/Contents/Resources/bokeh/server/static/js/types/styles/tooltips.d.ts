export declare const bk_tooltip = "bk-tooltip";
export declare const bk_tooltip_arrow = "bk-tooltip-arrow";
export declare const bk_tooltip_custom = "bk-tooltip-custom";
export declare const bk_tooltip_row_label = "bk-tooltip-row-label";
export declare const bk_tooltip_row_value = "bk-tooltip-row-value";
export declare const bk_tooltip_color_block = "bk-tooltip-color-block";
