export declare const bk_menu = "bk-menu";
export declare const bk_caret = "bk-caret";
export declare const bk_divider = "bk-divider";
