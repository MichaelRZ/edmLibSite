export declare const bk_shading = "bk-shading";
