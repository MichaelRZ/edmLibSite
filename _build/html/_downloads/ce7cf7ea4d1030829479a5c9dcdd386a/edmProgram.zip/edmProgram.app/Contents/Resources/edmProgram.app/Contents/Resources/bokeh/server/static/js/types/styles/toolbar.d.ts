export declare const bk_toolbar = "bk-toolbar";
export declare const bk_toolbar_hidden = "bk-toolbar-hidden";
export declare const bk_toolbar_button = "bk-toolbar-button";
export declare const bk_button_bar = "bk-button-bar";
export declare const bk_toolbar_button_custom_action = "bk-toolbar-button-custom-action";
