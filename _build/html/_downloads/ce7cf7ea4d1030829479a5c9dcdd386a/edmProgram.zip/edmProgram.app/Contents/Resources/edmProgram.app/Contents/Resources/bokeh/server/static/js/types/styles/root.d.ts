export declare const bk_root = "bk-root";
