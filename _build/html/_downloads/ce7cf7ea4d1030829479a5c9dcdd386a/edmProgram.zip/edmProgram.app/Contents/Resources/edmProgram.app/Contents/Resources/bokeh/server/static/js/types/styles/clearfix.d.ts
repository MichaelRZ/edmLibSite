export declare const bk_clearfix = "bk-clearfix";
