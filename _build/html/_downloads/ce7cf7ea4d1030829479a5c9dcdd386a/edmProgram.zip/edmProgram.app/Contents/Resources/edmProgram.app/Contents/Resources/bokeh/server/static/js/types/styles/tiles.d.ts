export declare const bk_tile_attribution = "bk-tile-attribution";
