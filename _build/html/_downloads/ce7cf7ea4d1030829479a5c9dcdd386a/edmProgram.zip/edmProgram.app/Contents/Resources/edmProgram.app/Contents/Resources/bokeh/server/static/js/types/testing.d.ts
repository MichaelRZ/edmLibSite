export declare const results: Record<string, any>;
export declare function init(): void;
export declare function record0(key: string, value: any): void;
export declare function record(key: string, value: any): void;
export declare function count(key: string): void;
