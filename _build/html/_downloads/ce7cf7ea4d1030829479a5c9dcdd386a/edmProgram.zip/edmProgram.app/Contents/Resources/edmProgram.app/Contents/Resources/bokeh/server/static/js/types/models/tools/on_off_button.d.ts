import { ButtonToolButtonView } from "./button_tool";
export declare class OnOffButtonView extends ButtonToolButtonView {
    render(): void;
    protected _clicked(): void;
}
