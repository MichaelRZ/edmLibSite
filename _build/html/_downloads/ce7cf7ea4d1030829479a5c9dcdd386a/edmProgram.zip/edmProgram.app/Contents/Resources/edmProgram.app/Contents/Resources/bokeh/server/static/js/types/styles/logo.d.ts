export declare const bk_logo = "bk-logo";
export declare const bk_logo_notebook = "bk-logo-notebook";
export declare const bk_logo_small = "bk-logo-small";
export declare const bk_grey = "bk-grey";
