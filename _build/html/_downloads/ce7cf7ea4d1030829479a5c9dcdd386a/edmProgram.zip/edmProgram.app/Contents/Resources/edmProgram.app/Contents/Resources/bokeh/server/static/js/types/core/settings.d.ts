export declare class Settings {
    private _dev;
    set dev(dev: boolean);
    get dev(): boolean;
}
export declare const settings: Settings;
