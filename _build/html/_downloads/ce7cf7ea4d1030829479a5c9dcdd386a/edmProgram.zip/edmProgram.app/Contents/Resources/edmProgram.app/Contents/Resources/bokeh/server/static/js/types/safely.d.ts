export declare function safely<T>(fn: () => T, silent?: boolean): T | undefined;
