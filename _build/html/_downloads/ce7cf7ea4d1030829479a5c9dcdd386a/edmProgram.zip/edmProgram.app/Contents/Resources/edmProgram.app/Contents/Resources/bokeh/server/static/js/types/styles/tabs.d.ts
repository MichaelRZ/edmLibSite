export declare const bk_tabs_header = "bk-tabs-header";
export declare const bk_headers_wrapper = "bk-headers-wrapper";
export declare const bk_headers = "bk-headers";
export declare const bk_tab = "bk-tab";
export declare const bk_close = "bk-close";
